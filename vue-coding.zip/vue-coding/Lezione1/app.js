console.log("hello")


const app = Vue.createApp({
    //data , functions
    data(){
        return {
            title : "the final empire",
            author : "Sir Arthur Conan Doyle",
            age : 32
        }
    }
    //template: '<h2>WOW THIS MY APP </h2>'
});


app.mount('#app');

