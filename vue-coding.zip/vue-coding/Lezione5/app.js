const app = Vue.createApp({

    data() {

        return {
           books :[
               {title :'name of the wind', author:'patric', img :'assets/corporate.jpg', isFav :true},
               {title :'name of the book', author:'samantra' ,img :'assets/exel.jpg' , isFav :false},
               {title :'name of the spieel', author:'crocodile' ,img :'assets/exel.jpg', isFav :true}
           ],

           //url
           //usato per il binding
           url:"http://google.it"
           
        }

    },
    methods: {
       
    },

    //dipende dai dati
    //quando i dati cambiano cambia anch'essa
    computed : {
        filteredBooks(){
            return this.books.filter((book) => book.isFav );
        }
    }

})

app.mount("#app")