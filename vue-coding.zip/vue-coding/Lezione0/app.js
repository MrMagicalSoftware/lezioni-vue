console.log("hello")


const app = Vue.createApp({
  
    template: '<h2>WOW THIS MY APP </h2>'
});


app.mount('#app');

