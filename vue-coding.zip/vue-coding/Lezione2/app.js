const app = Vue.createApp({

    data() {

        return {
            title :"i misteri di skerlock",
            author :"Sir Author Conand Doyl",
            age : 32
        }

    },
    methods: {
        changeTitle(){
            console.log("u click here")
            this.title ="Nuovo titolo";
        },
        changeTitle(title){
            console.log("u click here")
            this.title =title;
        }
    }

})

app.mount("#app")