const app = Vue.createApp({

    data() {

        return {
            showBooks:true,
            title :"i misteri di skerlock",
            author :"Sir Author Conand Doyl",
            age : 32,
            score :0,
            x :0,
            y :0
        }

    },
    methods: {
        changeTitle(){
            console.log("u click here")
            this.title ="Nuovo titolo";
        },
        changeTitle(title){
            console.log("u click here")
            this.title =title;
        },
        hideBooks(){
            this.showBooks=false
        },
        toggleShowBooks(){
            this.showBooks = !this.showBooks;
        },
        handleMouseOver(){
            console.log("wow mouse over here")
            this.score++;
        },
        handlerMouse(e){
            console.log(e, e.type);
        },
        handerMouseMove(e){
            this.x = e.offsetX
            this.y = e.offsetY
        }
    }

})

app.mount("#app")